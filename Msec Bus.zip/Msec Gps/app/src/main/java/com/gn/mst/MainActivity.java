package com.gn.mst;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationRequest;
import android.os.Bundle;
import android.os.Handler;

import android.os.StrictMode;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Network;
import com.android.volley.RequestQueue;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;

import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import org.json.JSONException;


public class MainActivity extends AppCompatActivity {

    private String data;

    private static Context mContext;
    private GoogleMap mMap;
    private GoogleMap gMap;

    private String json;
    private String lat = "9.235940";
    private String lon = "78.760240";
    private Double lati;
    private Double loni;
    private String speed = "00";
    private String time = "Updating";
    Marker mCurrLocationMarker;
    private TextView sped;
    private TextView date;
    private TextView loc;
    private MapView mapview1;
    private GoogleMapController _mapview1_controller;
    private static final String TAG = "LocationActivity";
    private static final long INTERVAL = 2000; //1.5 min
    private static final long FASTEST_INTERVAL = 1000; //1.5 min
    private static final long DISPLACEMENT = 5; //5 meter
    private LocationRequest mLocationRequest;
    private GoogleApiClient mGoogleApiClient;
    private Location mLastLocation;
    private Location oldLocation;
    private Context context;
    private int markerCount = 0;
    private SupportMapFragment mapFragment;
    private static final int REQUEST_LOCATION = 0;
    private boolean isFirstTime = true;
    private Marker marker;
    private FloatingActionButton click;
    private FloatingActionButton gpsc;
    private Location location;

    private LocationManager gps;
    private LocationListener _gps_location_listener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);





        initialize(savedInstanceState);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, 1000);
        }
        else {
            initializeLogic();
        }
        displayLocation();

    }


//        final Handler handler = new Handler();
//        Timer timer = new Timer();
//        TimerTask doAsynchronouslyTask = new TimerTask() {
//            @Override
//            public void run() {
//                handler.post(new Runnable() {
//                    @Override
//                    public void run() {
//                        try {
//                            apiRequest("update=0");
//                        }catch (Exception e) {
//                            Toast.makeText(getApplicationContext(), e.toString(),Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                });
//            }
//        };
//        timer.schedule(doAsynchronouslyTask, 0, 1000);





    private void initialize(Bundle savedInstanceState) {

        sped = (TextView) findViewById(R.id.speed);
        date = (TextView) findViewById(R.id.date);
        loc = (TextView) findViewById(R.id.loc);
        click = (FloatingActionButton) findViewById(R.id.floatingActionButton);
        gpsc = (FloatingActionButton) findViewById(R.id.gps);

        sped.setText("00");
        date.setText("Updating");
        getAddress(Double.parseDouble(lat), Double.parseDouble(lon));


        mapview1 = (MapView) findViewById(R.id.map);
        mapview1.onCreate(savedInstanceState);





        LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE );
        boolean statusOfGPS = manager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        if(statusOfGPS){

        }

        else{
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(intent);

        }
        _mapview1_controller = new GoogleMapController(mapview1, new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap) {
                mMap = googleMap;
                _mapview1_controller.setGoogleMap(mMap);


                try {
                    boolean success = googleMap.setMapStyle(
                            MapStyleOptions.loadRawResourceStyle(
                                    MainActivity.this, R.raw.mapstyle));


                    if (!success) {

                        Log.e("MainActivity", "Style parsing failed.");
                    }
                } catch (Resources.NotFoundException e) {
                    Log.e("MainActivity", "Can't find style. Error: ", e);
                }


                LatLng college = new LatLng(9.2346424d, 78.7596154d);
                mMap.addMarker(new MarkerOptions().position(college).icon(BitmapDescriptorFactory
                        .fromResource(R.drawable.img)));
                CameraPosition cameraPosition = new CameraPosition.Builder().target(new LatLng(college.latitude, college.longitude)).zoom(16).build();
                mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

                // Add a marker in Sydney and move the camera

            }

        });

        click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View _view) {
                _mapview1_controller.moveCamera(Double.parseDouble(lat), Double.parseDouble(lon));

                mMap.animateCamera(CameraUpdateFactory.zoomIn());
                mMap.animateCamera(CameraUpdateFactory.zoomTo(10), 2000, null);
                LatLng mountainView = new LatLng(Double.parseDouble(lat), Double.parseDouble(lon));
                CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(mountainView)
                        .zoom(15)
                        .bearing(180)
                        .tilt(55)
                        .build();
                mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

















            }
        });





        _gps_location_listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location _param1) {
                final String result;
                final Integer dis;
                final double _lat = _param1.getLatitude();
                final double _lng = _param1.getLongitude();
                lati=_param1.getLatitude();
                loni=_param1.getLongitude();
                final double la ;
                final double ln ;
                la =lati;
                ln = loni;
                _mapview1_controller.setMarkerPosition("gps", _lat, _lng);

                float[] results = new float[5];
                Location.distanceBetween(_lat, _lng, la,ln, results);
                result=String.valueOf(results[0]);
                int a = (int) Double.parseDouble(result);
                int b = a / 1000;
                dis=b;
                if(b==0){
                    _mapview1_controller.setMarkerVisible("gps",false);
                }
                else {
                    _mapview1_controller.setMarkerInfo("gps", "Your here", "The distance between you and the bus is " + String.valueOf(dis).concat(".".concat("Km")));
                }
                gpsc.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View _view) {
                        _mapview1_controller.moveCamera(lati, loni);
                        _mapview1_controller.zoomTo(16);
                        mMap.animateCamera(CameraUpdateFactory.zoomIn());
                        // Zoom out to zoom level 10, animating with a duration of 2 seconds.
                        mMap.animateCamera(CameraUpdateFactory.zoomTo(10), 2000, null);
                        LatLng mountainView = new LatLng(lati, loni);
                        CameraPosition cameraPosition = new CameraPosition.Builder()
                                .target(mountainView )      // Sets the center of the map to Mountain View
                                .zoom(18)                   // Sets the zoom
                                .bearing(180)                // Sets the orientation of the camera to east
                                .tilt(55)                   // Sets the tilt of the camera to 30 degrees
                                .build();                   // Creates a CameraPosition from the builder
                        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                        String distance = String.valueOf(dis).concat(" Km");
                        if(dis==0){
                            Toast.makeText(getApplicationContext(), "The bus has come close and stay there", Toast.LENGTH_SHORT).show();

                        }
                        else {

                            Toast.makeText(getApplicationContext(), "Bus Distance ".concat(distance), Toast.LENGTH_SHORT).show();
                        }
                    }
                });


            }
            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {}
            @Override
            public void onProviderEnabled(String provider) {}
            @Override
            public void onProviderDisabled(String provider) {}
        };














    }


    public void initializeLogic(){
        // Retrieving the value using its keys the file name
// must be same in both saving and retrieving the data
        SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_APPEND);

// The value will be default as empty string because for
// the very first time when the app is opened, there is nothing to show
        String bus = sh.getString("bus", "");
        int a = sh.getInt("age", 0);

        url_data(bus);



    }
    // data request **********************************************
    private void url_data (String bus_num){

        RequestQueue requestQueue;

        DiskBasedCache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024); // 1MB cap
        Network network = new BasicNetwork(new HurlStack());
        requestQueue = new RequestQueue(cache, network);
        requestQueue.start();
        String url = "http://104.237.9.130/bus_data/?device_id="+bus_num;

        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    if (response.length() > 0) {

                        //Toast.makeText(getApplicationContext(), response,Toast.LENGTH_SHORT).show();
                        JSONArray arr = null;
                        try {
                            arr = new JSONArray(response);
                            JSONObject jObj = arr.getJSONObject(0);
                            time = jObj.getString("add_date");
                            lat = jObj.getString("lati");
                            lon = jObj.getString("longi");
                            speed = jObj.getString("speed");

                            String extensionRemoved = speed.split("\\.")[0];
                            sped.setText(extensionRemoved + '\n' + "Mph");

                            String[] newStr = time.split("\\s+");

                            date.setText(newStr[1]);


                            getAddress(Double.parseDouble(lat), Double.parseDouble(lon));


                            LatLng sydney = new LatLng(Double.parseDouble(lat), Double.parseDouble(lon));
                            CameraPosition cameraPosition = new CameraPosition.Builder().target(new LatLng(sydney.latitude, sydney.longitude)).zoom(16).build();
                            mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));


                            // Creating a marker
                            MarkerOptions markerOptions = new MarkerOptions();


                            // Setting the position for the marker
                            markerOptions.position(sydney);
                            markerOptions.icon(BitmapDescriptorFactory
                                    .fromResource(R.drawable.marker));

                            // Setting the title for the marker.
                            // This will be displayed on taping the marker
                            markerOptions.title("Speed :" + speed + " - " + "Time :" + time);

                            // Clears the previously touched position
                            mMap.clear();

                            // Animating to the touched position
//                            mMap.animateCamera(CameraUpdateFactory.newLatLng(sydney));

                            // Placing a marker on the touched position
                            mMap.addMarker(markerOptions);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
        queue.add(stringRequest);


    }




    public void getAddress(double lat, double lng) {
        Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
            Address obj = addresses.get(0);
            String add = obj.getAddressLine(0);
//            add = add + "\n" + obj.getCountryName();
//            add = add + "\n" + obj.getCountryCode();
//            add = add + "\n" + obj.getAdminArea();
//            add = add + "\n" + obj.getPostalCode();
//            add = add + "\n" + obj.getSubAdminArea();
//            add = add + "\n" + obj.getLocality();
//            add = add + "\n" + obj.getSubThoroughfare();

            Log.v("IGA", "Address" + add);
            Toast.makeText(this, "" + add,
                    Toast.LENGTH_SHORT).show();
            loc.setText(add);




            //   MapsActivity.showDialog(add);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapview1.onDestroy();
    }

    @Override
    public void onStart() {
        super.onStart();
        mapview1.onStart();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapview1.onPause();
    }
    @Override
    public void onResume() {
        super.onResume();
        mapview1.onResume();
    }

    @Override
    public void onStop() {
        super.onStop();
        mapview1.onStop();
    }



    public void displayLocation() {
        try {

            if (ActivityCompat.checkSelfPermission(context,
                    Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(context,
                            Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                // Check Permissions Now
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        REQUEST_LOCATION);
            } else {


                mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

                if (mLastLocation != null && mLastLocation.getLongitude() != 0.0 && mLastLocation.getLongitude() != 0.0) {

                    if (mMap != null) {

                        _mapview1_controller.setGoogleMap(mMap);
                        _mapview1_controller.addMarker("gps", mLastLocation.getLatitude(), mLastLocation.getLongitude());
                        _mapview1_controller.setMarkerInfo("gps", "Mohammad sathak engineering college", "Our college");
                        _mapview1_controller.setMarkerIcon("gps", R.drawable.collafe);



                    }

                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }




}